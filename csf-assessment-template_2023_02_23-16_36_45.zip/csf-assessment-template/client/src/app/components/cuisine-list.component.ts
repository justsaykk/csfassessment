import { Component } from '@angular/core';

@Component({
  selector: 'app-cuisine-list',
  templateUrl: './cuisine-list.component.html',
  styleUrls: ['./cuisine-list.component.css']
})
export class CuisineListComponent {

	// TODO Task 2
	// For View 1

}
