package vttp2022.csf.assessment.server.repositories;

public class MapCache {

	// TODO Task 4
	// Use this method to retrieve the map
	// You can add any parameters (if any) and the return type 
	// DO NOT CHNAGE THE METHOD'S NAME
	public ??? getMap(???) {
		// Implmementation in here
		
	}

	// You may add other methods to this class

}
